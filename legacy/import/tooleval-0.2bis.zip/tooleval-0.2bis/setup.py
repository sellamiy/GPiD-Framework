from setuptools import setup

setup(name='tooleval',
      version='0.2',
      description='Framework for prototypes evaluations',
      url='',
      author='Y. Sellami',
      author_email='yanisellami@gmail.com',
      licence='MIT',
      packages=['tooleval'],
      scripts=['bin/toolevalc'],
      install_requires=[
          'dill',
          'colorama',
          'numpy', 'matplotlib',
          'antlr4-python3-runtime'
      ],
      include_package_data=True,
      zip_safe=False)
