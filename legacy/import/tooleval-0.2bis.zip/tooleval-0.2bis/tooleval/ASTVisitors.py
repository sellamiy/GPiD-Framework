# ======================================
from .ToolEvaluationAST import IdentifierNode, DummySymbolLocation
from .ToolEvaluationAST import ASTContextSymbol, ASTVisitor
from .ToolEvaluationLogger import LocatedWarningMessage
from .ToolEvaluationErrors import TesContextError
from . import ToolEvaluation as te
# ======================================
ASTContextRoot    = ASTContextSymbol('<root>')
ASTContextType    = ASTContextSymbol('<type>')
ASTContextParent  = ASTContextSymbol('<parent>')
ASTContextScripts = ASTContextSymbol('<scripts>')
# ======================================
GLOBAL_ID = 0
def new_id():
    global GLOBAL_ID
    GLOBAL_ID += 1
    return IdentifierNode(DummySymbolLocation, str(GLOBAL_ID))
# ======================================
# Call Contexts
# --------------------------------------
class GenericCallContext:

    def _refuse_subparts(self, node):
        if node.fpart is not None:
            func_name = node.fname.name.capitalize()
            raise TesContextError('%s function does not allow subpart' % func_name, node.fpart.location)

    def _ensure_subpart(self, node):
        if node.fpart is None:
            func_name = node.fname.name.capitalize()
            raise TesContextError('%s function requires subpart' % func_name, node.location)

    def _check_parameters_count(self, node, minc=None, maxc=None):
        func_name = node.fname.name.capitalize()
        count = len(node.parameters) if node.parameters else 0
        if minc is not None and count < minc:
            raise TesContextError('%s function requires at least %i parameter' % (func_name, minc),
                                  node.location)
        if maxc is not None and count > maxc:
            raise TesContextError('%s function accepts at most %i parameter' % (func_name, maxc),
                                  node.parameters[maxc-1].location)

    def _check_type(self, value, type_n, loc):
        if value not in type_n:
            raise TesContextError('Illegal type: %s -- expected %s' % (value, type_n), loc)

    def _check_filepart_type(self, value, loc):
        self._check_type(value, ('NonParametrizedString'), loc)

    def _check_format_type(self, value, loc):
        self._check_type(value, ('ParametrizedString', 'NonParametrizedString'), loc)

    def _check_numeric_type(self, value, loc):
        self._check_type(value, ('Float'), loc)

    def _check_value_type(self, value, loc):
        self._check_type(value, ('Access'), loc)

    def _check_filter_type(self, value, loc):
        self._check_type(value, ('FunctionCall'), loc)

    def _set_context_type(self, constructor, ctx):
        ctx[ASTContextType] = constructor if constructor is not None else self._rnone

    def _rnone(self):
        return None

# --------------------------------------
class RequirementCallContext(GenericCallContext):

    def handleChange_filename(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=2, maxc=2)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_filepart_type(type_0, node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        type_1 = type(node.parameters[1]).__name__.replace('Node', '')
        self._check_filepart_type(type_1, node.parameters[1].location)
        param_1 = visitor.build(node.parameters[1], ctx)

        parent.add_step(te.SourceUpdateInstruction(param_0, param_1))
        self._set_context_type(None, ctx)

    def handleEnsure_exists(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=0, maxc=0)
        parent = ctx[ASTContextParent]
        parent.add_step(te.EnsureSourceExistsInstruction())
        self._set_context_type(None, ctx)

    def handleGenerate_with(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=2, maxc=2)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('Identifier'), node.parameters[0].location)
        param_0 = visitor.buildGetter(node.parameters[0], ctx)

        type_1 = type(node.parameters[1]).__name__.replace('Node', '')
        self._check_type(type_1, ('Reference'), node.parameters[1].location)
        param_1 = visitor.buildGetter(node.parameters[1], ctx)

        parent.set_generator(te.RequirementGenerator(param_0, param_1))
        self._set_context_type(None, ctx)
# --------------------------------------
class OptionCallContext(GenericCallContext):

    def handleUpdate_format(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_format_type(type_0, node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        parent.change_format(param_0)
        self._set_context_type(None, ctx)

    def handleAdd_option(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_format_type(type_0, node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        parent.add_cli_option(param_0)
        self._set_context_type(None, ctx)
# --------------------------------------
class GenericDataHandlerCallContext(GenericCallContext):

    _type_values = {
            'int'       : int,
            'float'     : float,
            'complex'   : complex,
            'bool'      : bool,
            'ascii'     : ascii,
            'bytearray' : bytearray,
            'bytes'     : bytes,
            'callable'  : callable,
            'dict'      : dict,
            'frozenset' : frozenset,
            'hash'      : hash,
            'hex'       : hex,
            'id'        : id,
            'list'      : list,
            'object'    : object,
            'oct'       : oct,
            'set'       : set,
            'str'       : str,
            'tuple'     : tuple
        }

    def _buildConverter(self, ident, loc):
        try:
            return self._type_values[ident]
        except KeyError:
            raise TesContextError('Unknown Python3 Type: %s' % ident, loc)
# --------------------------------------
class ResultCallContext(GenericDataHandlerCallContext):

    def handleParse(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_format_type(type_0, node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        parent.add_step(te.ParseLinesInstruction(param_0))
        self._set_context_type(str, ctx)

    def handleConvert(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('Identifier'), node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        converter = self._buildConverter(param_0, node.parameters[0].location)
        parent.add_step(te.SourceFunctionApplier(converter))
        self._set_context_type(converter, ctx)

    def handleConvert_elements(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('Identifier'), node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        converter = self._buildConverter(param_0, node.parameters[0].location)
        parent.add_step(te.SourceFunctionApplier(lambda l : [ converter(e) for e in l ]))
        self._set_context_type(converter, ctx)

    def handleFind(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_format_type(type_0, node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        parent.add_step(te.FindLinesInstruction(param_0))
        self._set_context_type(str, ctx)

    def handleScale(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_numeric_type(type_0, node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        parent.add_step(te.SourceFunctionApplier(lambda x : param_0 * x))
        self._set_context_type(type(param_0), ctx)

    def handleColumn(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('Integer'), node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        parent.add_step(te.RecoverColumnInstruction(param_0))
        self._set_context_type(int, ctx)

    def handleSplit_along(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('NonParametrizedString'), node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        split_function = lambda x : [ d for d in x.split(param_0) if d ]
        parent.add_step(te.SourceFunctionApplier(split_function))
        self._set_context_type(str, ctx)

    def handleAs_set(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, maxc=0)
        parent = ctx[ASTContextParent]

        parent.add_step(te.RawSourceFunctionApplier(set))
        self._set_context_type(None, ctx)
# --------------------------------------
class DatamapCallContext(GenericDataHandlerCallContext):

    def handleLoad(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('Reference'), node.parameters[0].location)
        param_0 = visitor.buildGetter(node.parameters[0], ctx)

        parent.add_step(te.LoadDatamapInstruction(param_0))
        self._set_context_type(None, ctx)

    def handleSplit_along(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('NonParametrizedString'), node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        split_function = lambda l : [ [ d for d in e.split(param_0) if d ] for e in l ]
        parent.add_step(te.DictSourceFunctionApplier(split_function))
        self._set_context_type(str, ctx)

    def handleConvert(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('Identifier'), node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        converter = self._buildConverter(param_0, node.parameters[0].location)
        parent.add_step(te.DictSourceFunctionApplier(lambda l : [ converter(e) for e in l]))
        self._set_context_type(converter, ctx)

    def handleConvert_elements(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('Identifier'), node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        converter = self._buildConverter(param_0, node.parameters[0].location)
        parent.add_step(te.DictSourceFunctionApplier(lambda l : [ [ converter(e) for e in t ] for t in l]))
        self._set_context_type(converter, ctx)

    def handleAs_set(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, maxc=0)
        parent = ctx[ASTContextParent]

        parent.add_step(te.DictSourceFunctionApplier(set))
        self._set_context_type(None, ctx)
# --------------------------------------
class EvaluationCallContext(GenericCallContext):

    def handleAdd_option(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_format_type(type_0, node.parameters[0].location)
        param_0 = visitor.build(node.parameters[0], ctx)

        parent.add_additional_option(param_0)
        self._set_context_type(None, ctx)
# --------------------------------------
class ProblemSetCallContext(GenericCallContext):

    def handleLines(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('Reference'), node.parameters[0].location)
        param_0 = visitor.buildGetter(node.parameters[0], ctx)

        loader = te.LoadLinesFromInstruction(param_0)
        parent.add_step(loader)
        self._set_context_type(None, ctx)
# --------------------------------------
class ScriptCallContext(GenericCallContext):

    def __init__(self):
        self._local_ctx = []

    def _push_local_ctx(self, symbol):
        self._local_ctx.append(symbol)

    def _pop_local_ctx(self):
        self._local_ctx.pop()

    def _get_local_caller(self, ctx, symbol):
        if self._local_ctx:
            try:
                return ctx[self._local_ctx[-1]].get(symbol.name)
            except AttributeError as e:
                raise TesContextError(str(e), symbol.loc)
        else:
            return ctx[symbol]

    def handle(self, node, ctx, visitor):
        parent = ctx[ASTContextParent]

        symbol = ASTContextSymbol(node.fname.name, node.location)
        caller = self._get_local_caller(ctx, symbol)
        if node.fpart:
            try:
                caller = caller.get(node.fpart.name)
            except AttributeError as e:
                raise TesContextError(str(e), node.fpart.location)

        if not caller.can_be_called():
            ctype = type(caller).__name__
            raise TesContextError('This variable is not callable (Type %s)' % ctype, node.location)

        param_min, param_max = caller.get_parameters_range()
        self._check_parameters_count(node, minc=param_min, maxc=param_max)

        self._push_local_ctx(symbol)
        parameters = []
        if node.parameters:
            for parameter in node.parameters:
                parameters.append(visitor.buildGetter(parameter, ctx))
        self._pop_local_ctx()
        instruction = te.ScriptCallInstruction(caller, parameters)
        parent.add_step(instruction)
        self._set_context_type(te.EvaluationResultHanger, ctx)

    def handleSave_context(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=0, maxc=0)
        parent = ctx[ASTContextParent]
        parent.add_step(te.SaveContextInstruction())
        self._set_context_type(None, ctx)

    def handleLoad_context(self, node, ctx, visitor):
        self._refuse_subparts(node)
        self._check_parameters_count(node, minc=1, maxc=1)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        self._check_type(type_0, ('Reference', 'Access'), node.parameters[0].location)
        param_0 = visitor.buildGetter(node.parameters[0], ctx)

        loader = te.LoadContextInstruction(param_0)
        parent.add_step(loader)
        self._set_context_type(None, ctx)

    def _build_graph_parameters(self, node, ctx, visitor):
        parameters = []
        filters = []
        at_parameters = True
        for parameter in node.parameters:
            type_p = type(parameter).__name__.replace('Node', '')
            if at_parameters:
                try:
                    self._check_value_type(type_p, parameter.location)
                    param_p = visitor.buildGetter(parameter, ctx)
                    parameters.append(param_p)
                except TesContextError:
                    at_parameters = False
            if not at_parameters:
                self._check_filter_type(type_p, parameter.location)
                param_p = visitor.buildGetter(parameter, ctx)
                filters.append(param_p)
        return parameters, filters

    def handleGraph(self, node, ctx, visitor):
        self._ensure_subpart(node)
        handler = '_handle%s' % node.fpart.name.capitalize()
        try:
            getattr(self, handler)(node, ctx, visitor)
        except AttributeError as e:
            LocatedWarningMessage(str(e), node.fpart.location)
            raise TesContextError('Unknown graph subpart: %s' % node.fpart.name, node.fpart.location)

    def _handleCompare(self, node, ctx, visitor):
        self._check_parameters_count(node, minc=2)
        parent = ctx[ASTContextParent]
        parameters, filters = self._build_graph_parameters(node, ctx, visitor)
        pcount = len(parameters)
        if pcount < 2:
            raise TesContextError('Not enough series for a compare graph (min 2)', node.location)
        parent.add_step(te.MakeCompareGraphInstruction(parameters, filters))
        self._set_context_type(te.GraphHanger, ctx)

    def _handleHistogram(self, node, ctx, visitor):
        self._check_parameters_count(node, minc=1)
        parent = ctx[ASTContextParent]
        parameters, filters = self._build_graph_parameters(node, ctx, visitor)
        pcount = len(parameters)
        if pcount != 1:
            raise TesContextError('Histogram requires exactly one serie - Found %i' % pcount, node.location)
        parent.add_step(te.MakeHistogramInstruction(parameters, filters))
        self._set_context_type(te.GraphHanger, ctx)

    def handleEnsure(self, node, ctx, visitor):
        self._ensure_subpart(node)
        handler = '_handleEnsure%s' % node.fpart.name.capitalize()
        try:
            getattr(self, handler)(node, ctx, visitor)
        except AttributeError as e:
            LocatedWarningMessage(str(e), node.fpart.location)
            raise TesContextError('Unknown ensurer: %s' % node.fpart.name, node.fpart.location)

    def _handleEnsureEqual(self, node, ctx, visitor):
        self._check_parameters_count(node, minc=2, maxc=2)
        parent = ctx[ASTContextParent]

        type_0 = type(node.parameters[0]).__name__.replace('Node', '')
        param_0 = visitor.buildGetter(node.parameters[0], ctx)

        type_1 = type(node.parameters[1]).__name__.replace('Node', '')
        param_1 = visitor.buildGetter(node.parameters[1], ctx)

        parent.add_step(te.DataEnsureInstruction(param_0, param_1, te.EqualityEnsurer))
        self._set_context_type(None, ctx)
# ======================================

# ======================================
# Main Script Visitor
# --------------------------------------
class ScriptBuilderVisitor(ASTVisitor):

    _CallContexts = {
        'Requirement' : RequirementCallContext(),
        'Option' : OptionCallContext(),
        'Result' : ResultCallContext(),
        'Datamap' : DatamapCallContext(),
        'Evaluation' : EvaluationCallContext(),
        'ProblemSet' : ProblemSetCallContext(),
        'Script' : ScriptCallContext()
    }

    def buildScript(self, node, ctx):
        self._cblock = []
        self._parents = []
        ctx[ASTContextRoot]    = []
        ctx[ASTContextType]    = None
        ctx[ASTContextParent]  = None
        ctx[ASTContextScripts] = []
        for block in node.blocks:
            self.build(block, ctx)
        return ctx[ASTContextScripts]

    def _push_context(self, node, ctx):
        self._cblock.append(node)
        ctx[ASTContextRoot].append('%s' % node.name.name)
        for pos in range(node.bparams):
            param = pos+1
            ctx[ASTContextSymbol(str(param), node.name.location)] = te.ParameterReference(param)

    def _pop_context(self, ctx):
        ctx[ASTContextRoot].pop()
        self._cblock.pop()

    def _handle_decorators(self, node, ctx):
        pass # TODO

    def _buildContent(self, node, block, ctx):
        self._push_parent(block, ctx)
        content_id = 0
        for content in node.content:
            content_id += 1
            block.new_part(content_id)
            for part in content:
                data = self.build(part, ctx)
                try:
                    block.add_data(data)
                except AttributeError as e:
                    raise TesContextError(str(e), part.location)
        self._pop_parent(ctx)

    def buildBlock(self, node, ctx):
        # Handle block context
        self._push_context(node, ctx)
        self._handle_decorators(node, ctx)
        # Create block data
        builder = 'build%sBlock' % node.btype.name
        try:
            block = getattr(self, builder)(node, ctx)
        except AttributeError as e:
            LocatedWarningMessage(str(e), node.btype.location)
            raise TesContextError('Unknown block type: %s' % node.btype.name, node.btype.location)
        # Load block content
        self._buildContent(node, block, ctx)
        # Save block and reset context
        self._pop_context(ctx)
        ctx[ASTContextSymbol(node.name.name, node.name.location)] = block
        return block

    def _push_parent(self, value, ctx):
        self._parents.append(ctx[ASTContextParent])
        ctx[ASTContextParent] = value

    def _pop_parent(self, ctx):
        ctx[ASTContextParent] = self._parents.pop()

    def _check_block_count(self, node, minc=None, maxc=None):
        count = len(node.content)
        block_name = type(node).__name__.replace('None', '')
        if minc is not None and count < minc:
            raise TesContextError('%s block type requires at least %i blocks' % (block_name, minc),
                                  node.location)
        if maxc is not None and count > maxc:
            raise TesContextError('%s block type accepts at most %i blocks' % (block_name, maxc),
                                  node.content[maxc-1].location)

    def buildToolBlock(self, node, ctx):
        block = te.Tool(node.name.name, node.bparams)
        self._check_block_count(node, minc=1, maxc=1)
        return block

    def buildExecutableDef(self, node, ctx):
        parent = ctx[ASTContextParent]
        try:
            parent.set_executable(node.value.value)
        except AttributeError as e:
            raise TesContextError(str(e), node.location)

    def buildFormatDef(self, node, ctx):
        parent = ctx[ASTContextParent]
        try:
            parent.set_format(node.value.value)
        except AttributeError as e:
            raise TesContextError(str(e), node.location)

    def buildEvaluationRequest(self, node, ctx):
        parent = ctx[ASTContextParent]
        symbol = ASTContextSymbol(node.ref.name, node.ref.location)
        if node.ref.name == 'basic':
            esymbol = ASTContextSymbol('', node.ref.location)
            ctx[esymbol] = te.Evaluation('', 0)
            parent.add_evaluation(ctx[esymbol])
        else:
            parent.add_evaluation(ctx[symbol], dry=True)

    def buildRequirementBlock(self, node, ctx):
        block = te.Requirement(node.name.name, node.bparams)
        self._check_block_count(node, minc=1, maxc=1)
        return block

    def _getCall(self, node, ctx):
        parent = ctx[ASTContextParent]
        parent_type = type(parent).__name__
        if parent_type not in self._CallContexts:
            raise TesContextError('No function call allowed inside %s type' % parent_type, node.location)
        call_context = self._CallContexts[parent_type]
        strict_handler = 'handle%s' % node.fname.name.capitalize()
        generic_handler = 'handle'
        if hasattr(call_context, strict_handler):
            return getattr(call_context, strict_handler)
        elif hasattr(call_context, generic_handler):
            return getattr(call_context, generic_handler)
        else:
            raise TesContextError('Unknown function name in %s type: %s' % (parent_type, node.fname.name),
                                  node.location)

    def buildFunctionCall(self, node, ctx):
        call_builder = self._getCall(node, ctx)
        call_builder(node, ctx, self)

    def buildFunctionCallGetter(self, node, ctx):
        parent = ctx[ASTContextParent]
        getter = te.StepResultGetter()
        ctx[ASTContextParent] = getter
        self._CallContexts[te.StepResultGetter.__name__] = self._CallContexts[type(parent).__name__]

        call_builder = self._getCall(node, ctx)
        call_builder(node, ctx, self)

        ctx[ASTContextParent] = parent
        return getter

    def buildNonParametrizedStringSetter(self, node, ctx):
        return te.FileExportSetter(node.value)

    def buildNonParametrizedStringGetter(self, node, ctx):
        return te.BasicValueGetter(node.value)

    def buildParametrizedStringGetter(self, node, ctx):
        return te.BasicValueGetter(node.value)

    def buildIntegerGetter(self, node, ctx):
        return te.BasicValueGetter(node.value)

    def buildNonParametrizedString(self, node, ctx):
        return node.value

    def buildParametrizedString(self, node, ctx):
        return node.value

    def buildFloat(self, node, ctx):
        return node.value

    def buildInteger(self, node, ctx):
        return node.value

    def buildIdentifier(self, node, ctx):
        return node.name

    def buildIdentifierGetter(self, node, ctx):
        symbol = ASTContextSymbol(node.name, node.location)
        return te.BasicContextGetter(ctx, symbol)

    def buildIdentifierSetter(self, node, ctx):
        symbol = ASTContextSymbol(node.name, node.location)
        return te.BasicContextSetter(ctx, symbol)

    def buildReferenceGetter(self, node, ctx):
        return te.LocalReferenceGetter(node.name)

    def buildOptionBlock(self, node, ctx):
        block = te.Option(node.name.name, node.bparams)
        self._check_block_count(node, minc=1, maxc=1)
        return block

    def buildResultBlock(self, node, ctx):
        block = te.Result(node.name.name, node.bparams)
        self._check_block_count(node, minc=1, maxc=1)
        return block

    def buildDatamapBlock(self, node, ctx):
        block = te.Datamap(node.name.name, node.bparams)
        self._check_block_count(node, minc=1, maxc=1)
        return block

    def buildRequirementRequest(self, node, ctx):
        parent = ctx[ASTContextParent]
        symbol = ASTContextSymbol(node.ref.name, node.ref.location)
        if node.ref.name == 'file':
            esymbol = ASTContextSymbol('file', node.ref.location)
            ctx[esymbol] = te.Requirement('file', 0)
            ctx[esymbol].add_step(te.EnsureSourceExistsInstruction())
            parent.add_requirement(ctx[esymbol])
        else:
            parent.add_requirement(ctx[symbol], dry=True)

    def buildEvaluationBlock(self, node, ctx):
        block = te.Evaluation(node.name.name, node.bparams)
        self._check_block_count(node, minc=1, maxc=1)
        return block

    def buildProblemSetBlock(self, node, ctx):
        block = te.ProblemSet(node.name.name, node.bparams)
        self._check_block_count(node, minc=1, maxc=1)
        return block

    def buildScriptBlock(self, node, ctx):
        block = te.Script(node.name.name, node.bparams)
        self._check_block_count(node, minc=1)
        ctx[ASTContextScripts].append(block)
        return block

    def buildAssignment(self, node, ctx):
        parent = ctx[ASTContextParent]

        value = self.buildGetter(node.value, ctx)

        for target in node.targets:

            if node.subtarget is None:
                if ctx.contextHas(target.name):
                    LocatedWarningMessage('Variable redifinition', target.location)
                    LocatedWarningMessage('Previous definition',
                                          ctx.contextLocation(target.name, target.location))
                ctx[ASTContextSymbol(target.name, target.location)] = ctx[ASTContextType]()
                setter = self.buildSetter(target, ctx)

            else:
                source = ctx[ASTContextSymbol(target.name, target.location)]
                subsetter = node.subtarget.name.capitalize()
                if not source.has(subsetter):
                    stype = type(source).__name__
                    LocatedWarningMessage('Target consideration failure', target.location)
                    raise TesContextError('Unknown subpart in type %s' % stype, node.subtarget.location)
                holder = self.buildGetter(target, ctx)
                setter = te.ObjectSetter(holder, subsetter)

            parent.add_step(te.AssignmentInstruction(setter, value))

    def buildAccessGetter(self, node, ctx):
        source = self.buildGetter(node.source, ctx)
        getter = te.ObjectGetter(source, node.name.name)
        return getter

    def buildFilterOutBlock(self, node, ctx):
        block = te.Filter(node.name.name, node.bparams, positive=False)
        self._check_block_count(node, minc=1, maxc=1)
        return block

    def buildBooleanConstraint(self, node, ctx):
        parent = ctx[ASTContextParent]
        getter = self.buildBooleanConstraintGetter(node, ctx)
        constraint = te.Constraint(getter)
        parent.add_constraint(constraint)

    def buildBooleanConstraintGetter(self, node, ctx):
        getter = te.OperationGetter(node.operation.operator)
        for p in node.parameters:
            getter.add_parameter(self.buildGetter(p, ctx))
        return getter

    def _build_id(self):
        return '?c<%s>' % new_id().name

    def buildConditionalBlock(self, node, ctx):
        parent = ctx[ASTContextParent]
        condition_getter = self.buildGetter(node.test, ctx)
        condition_content = te.Script(self._build_id(), 0)
        self._buildContent(node, condition_content, ctx)
        instruction = te.ConditionalInstruction(condition_getter, condition_content)
        parent.add_step(instruction)

    def buildVariableExport(self, node, ctx):
        parent = ctx[ASTContextParent]
        var_count = len(node.variables)
        tgt_count = len(node.targets)
        if var_count != tgt_count:
            raise TesContextError('L&R parts of variable export must be of the same size', node.location)

        for curr in range(var_count):
            getter = self.buildGetter(node.variables[curr], ctx)
            setter = self.buildSetter(node.targets[curr], ctx)
            parent.add_step(te.AssignmentInstruction(setter, getter))
# ======================================
