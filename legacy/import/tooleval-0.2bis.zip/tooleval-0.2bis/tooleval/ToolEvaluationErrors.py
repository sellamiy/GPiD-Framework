# ======================================
from colorama import Fore
from .ToolEvaluationLogger import PrintableMessage, PrintableLocatedMessage
# ======================================
# Exceptions
# ======================================
class TesError(Exception):
    pass
# ======================================
class TesCompilationError(TesError):
    def __init__(self, etype, msg, astsymb):
        super().__init__()
        self.etype = etype
        self.msg   = msg
        self.astsymb = astsymb
    def __str__(self):
        return str(PrintableLocatedMessage(self.etype, Fore.RED, Fore.GREEN, self.msg, self.astsymb))
# --------------------------------------
class TesSyntaxError(TesCompilationError):
    def __init__(self, msg, astsymb):
        super().__init__('Syntax Error', msg, astsymb)
class TesContextError(TesCompilationError):
    def __init__(self, msg, astsymb):
        super().__init__('Context Error', msg, astsymb)
class TesInternalError(TesCompilationError):
    def __init__(self, msg, astsymb):
        super().__init__('Internal Error', msg, astsymb)
# ======================================
class TesExecutionError(TesError):
    def __init__(self, etype, msg):
        self.etype = etype
        self.msg = msg
    def __str__(self):
        return str(PrintableMessage(self.etype, Fore.RED, self.msg))
# --------------------------------------
class TesImplementationError(TesExecutionError):
    def __init__(self, msg):
        super().__init__('Not Implemented Error', msg)
# --------------------------------------
class TesArgumentsError(TesExecutionError):
    def __init__(self, msg):
        super().__init__('Arguments Error', msg)
# --------------------------------------
class TesFileError(TesExecutionError):
    def __init__(self, msg):
        super().__init__('File Error', msg)
# --------------------------------------
class TesToolError(TesExecutionError):
    def __init__(self, msg):
        super().__init__('Tool Error', msg)
# --------------------------------------
class TesEnsureError(TesExecutionError):
    def __init__(self, msg):
        super().__init__('Ensure Error', msg)
# --------------------------------------
class TesInstructionError(TesExecutionError):
    def __init__(self, msg, instruction):
        super().__init__('Instruction Error', '{m} ({i})'.format(m=msg,i=instruction))
        self._source_instruction = instruction
# ======================================
