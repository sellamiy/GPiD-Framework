# ======================================
import sys, os, re
from pprint import pformat
from copy import deepcopy
from subprocess import Popen, STDOUT, PIPE
# ======================================
from .ToolEvaluationLogger import WarningMessage
from .ToolEvaluationErrors import TesExecutionError
from .ToolEvaluationErrors import TesImplementationError, TesArgumentsError, TesInstructionError
from .ToolEvaluationErrors import TesFileError, TesToolError, TesEnsureError
# ======================================
from . import ToolEvaluationGraphs as Teg
# ======================================
# Basic Structures
# --------------------------------------
class ToolEvaluationObject:

    def __init__(self, ident, pcount):
        self.ident = ident
        self.pcount = pcount

    def get_type(self):
        return type(self).__name__

    def new_part(self, part_id):
        raise AttributeError('new_part', self)

    def set_executable(self, value):
        raise AttributeError('Illegal type for setting executable: %s' % self.get_type())

    def set_format(self, value):
        raise AttributeError('Illegal type for setting format: %s' % self.get_type())

    def add_evaluation(self, e, dry=False):
        raise AttributeError('Illegal type for adding evaluation: %s' % self.get_type())

    def add_step(self, s):
        raise AttributeError('Illegal type for adding step: %s' % self.get_type())

    def add_data(self, d):
        if type(d) != type(None):
            raise AttributeError('Illegal type for adding data: %s' % self.get_type())

    def can_be_called(self):
        return False

    def get_parameters_range(self):
        raise AttributeError('Parameter range not implemented for type: %s' % self.get_type())

    def get(self, i):
        raise AttributeError('Illegal type for content access: %s' % self.get_type())

    def call(self, ctx):
        raise TesImplementationError('Call function not implemented for type %s' % self.get_type())

    def prepare(self):
        pass
# --------------------------------------
class ToolEvaluationSingleObject(ToolEvaluationObject):

    def new_part(self, part_id):
        pass
# --------------------------------------
class ParameterReference:
    def __init__(self, pos):
        self.pos = pos
    def prepare(self):
        pass
# --------------------------------------
class ArgumentListReference:
    def __init__(self):
        pass
# --------------------------------------
class ToolEvaluationGetter:

    def get_type(self):
        return type(self).__name__

    def get(self, args):
        raise TesImplementationError('Undefined getter for type %s' % self.get_type())
# --------------------------------------
class BasicValueGetter(ToolEvaluationGetter):

    def __init__(self, value):
        self.value = value

    def get(self, args):
        return self.value
# --------------------------------------
class BasicContextGetter(ToolEvaluationGetter):

    def __init__(self, ctx, ref):
        self.ctx = ctx
        self.ref = ref

    def get(self, args):
        return self.ctx[self.ref]
# --------------------------------------
class LocalReferenceGetter(ToolEvaluationGetter):

    class _ArgsGetter:
        def __init__(self, ctx):
            self._ctx = ctx
        def get(self, ident):
            return self._ctx.next_argument(ident)

    def __init__(self, ref):
        self.ref = ref

    def _get_args(self, ctx):
        return self._ArgsGetter(ctx)

    def _get_param(self, ctx):
        return ctx.params[int(self.ref) - 1]

    def get(self, ctx):
        if self.ref == 'args':
            return self._get_args(ctx)
        elif self.ref.isdigit():
            return self._get_param(ctx)
        return ctx.recover_reference(self.ref)
# --------------------------------------
class StepResultGetter(ToolEvaluationGetter):

    def __init__(self):
        self._internal_steps = []
        self._executed = False
        self._execution_result = None

    def add_step(self, s):
        self._internal_steps.append(s)

    def get(self, ctx):
        if not self._executed:
            for step in self._internal_steps:
                step.execute(ctx)
            self._execution_result = ctx.result
        return self._execution_result
# --------------------------------------
class ObjectGetter(ToolEvaluationGetter):

    def __init__(self, source_getter, part_name):
        self.source_getter = source_getter
        self.part_name = part_name

    def get(self, args):
        source_obj = self.source_getter.get(args)
        return source_obj.get(self.part_name)
# --------------------------------------
class OperationGetter(ToolEvaluationGetter):

    def __init__(self, operation_tag):
        self.operation_tag = operation_tag
        self.parameters = []

    def add_parameter(self, p):
        self.parameters.append(p)
# --------------------------------------
class ToolEvaluationSetter:

    def get_type(self):
        return type(self).__name__

    def set(self, value, ctx):
        raise TesImplementationError('Undefined setter for type %s' % self.get_type())
# --------------------------------------
class BasicContextSetter(ToolEvaluationSetter):

    def __init__(self, ctx, ref):
        self.ctx = ctx
        self.ref = ref

    def set(self, value, ctx):
        self.ctx[self.ref] = value
# --------------------------------------
class ObjectSetter(ToolEvaluationSetter):

    def __init__(self, source_getter, part_name):
        self.source_getter = source_getter
        self.part_name = part_name

    def set(self, value, ctx):
        source = self.source_getter.get(ctx)
        source.set(self.part_name, value)
# --------------------------------------
class FileExportSetter(ToolEvaluationSetter):

    def __init__(self, filename):
        self.filename = filename

    def set(self, value, ctx):
        if not hasattr(value, 'export_file'):
            otype = type(value).__name__
            raise TesArgumentsError('Object of type {ot} cannot be exported to a file'.format(ot=otype))
        value.export_file(self.filename)
# ======================================
# Problems Structures
# --------------------------------------
class ProblemSet(ToolEvaluationSingleObject):

    def __init__(self, ident, pcount):
        super().__init__(ident, pcount)
        self.load_steps = []

        self.examples = []

    def add_step(self, s):
        self.load_steps.append(s)

    def can_be_called(self):
        return len(self.load_steps) > 0

    def get_parameters_range(self):
        return self.pcount, self.pcount

    def call(self, ctx):
        ctx.set_source(self)
        for step in self.load_steps:
            step.execute(ctx)
        ctx.pop_source()

    def add(self, ident):
        self.examples.append(ident)

    def __iter__(self):
        return self.examples.__iter__()
# ======================================
# Instructions Structures
# ======================================
class EvaluationContext:
    def __init__(self, args, compilation_context):
        self.args = args
        self._comp_ctx = compilation_context
        self.source = None
        self.params = []
        self.result = None

        self._source_stack = []
        self._params_stack = []
    def set_source(self, s):
        self._source_stack.append(self.source)
        self.source = s
    def pop_source(self):
        self.source = self._source_stack.pop()
    def set_params(self, p):
        self._params_stack.append(self.params)
        self.params = p
    def pop_params(self):
        self.params = self._params_stack.pop()
    def set_result(self, r):
        self.result = r
    def clear_result(self):
        self.result = None

    def update_context(self, lctx):
        self._comp_ctx.update(lctx)

    def recover_reference(self, ref):
        return self._comp_ctx.contextGet(ref, None)

    def next_argument(self, name):
        if self.args:
            return self.args.pop(0)
        raise TesArgumentsError('Script requires an additional argument : %s' % name)
# ======================================
# --------------------------------------
class EvaluationInstruction:
    def execute(self, ctx):
        raise TesImplementationError(type(self).__name__)
    def _source(self, ctx):
        return ctx.result if ctx.result is not None else ctx.source
# --------------------------------------
class SourceUpdateInstruction(EvaluationInstruction):
    def __init__(self, str_find, str_repl):
        self.str_find = str_find
        self.str_repl = str_repl
# --------------------------------------
class EnsureSourceExistsInstruction(EvaluationInstruction):
    def execute(self, ctx):
        if not os.path.isfile(ctx.source):
            raise TesEnsureError('Source file {f} does not exists'.format(f=ctx.source))
# --------------------------------------
class ParseLinesInstruction(EvaluationInstruction):
    def __init__(self, pstring):
        self.pstring = pstring
    def execute(self, ctx):
        data = self._source(ctx)
        ctx.set_result(self._parse_lines(data))
    def _parse_lines(self, text):
        lines = text.split('\n')
        results = []
        for line in lines:
            value = self._get_parsed_data(line)
            if value is not None:
                results.append(value)
        return results if results else None
    def _get_parsed_data(self, text):
        matcher = self.pstring.replace('.', '\.').replace('$*', '.+')
        spliter = '$!'

        if spliter not in matcher:
            return matcher.strip() == text.strip()

        parts = matcher.split(spliter)
        parts = list(filter(''.__ne__, parts))
        matches = [ re.search(p, text) for p in parts ]
        matches = list(filter((None).__ne__, matches))

        if matches and len(matches) % 2 == 0:
            result = ''
            for idx in range(0, len(matches), 2):
                prepart  = matches[idx]
                postpart = matches[idx+1]
                result  += text[prepart.end():postpart.start()]
            return result

        if len(matches) == 1:
            part = matches[0]
            if matcher.strip().startswith(spliter):
                return text[:part.start()]
            if matcher.strip().endswith(spliter):
                return text[part.end():]
# --------------------------------------
class FindLinesInstruction(EvaluationInstruction):
    def __init__(self, pstring):
        self.pstring = pstring
# --------------------------------------
class RecoverColumnInstruction(EvaluationInstruction):
    def __init__(self, col_id):
        self.col_id = col_id
    def execute(self, ctx):
        data = self._source(ctx)
        ctx.set_result(self._extract_column(data))
    def _extract_column(self, text):
        lines = text.split('\n')
        for line in lines:
            value = self._get_column(line)
            if value is not None:
                return [ value ]
    def _get_column(self, line):
        cols = [c for c in line.split(' ') if c != '']
        if self.col_id < len(cols):
            return cols[self.col_id]
# --------------------------------------
class SourceFunctionApplier(EvaluationInstruction):
    def __init__(self, function):
        self.function = function
    def _compute_function(self, data):
        return [ self.function(e) for e in data ]
    def execute(self, ctx):
        try:
            data = self._source(ctx)
            ndata = self._compute_function(data)
            ctx.set_result(ndata)
        except Exception as e:
            raise TesInstructionError(str(e), self) from e
# --------------------------------------
class RawSourceFunctionApplier(SourceFunctionApplier):
    def _compute_function(self, data):
        return self.function(data)
# --------------------------------------
class DictSourceFunctionApplier(SourceFunctionApplier):
    def _compute_function(self, data):
        return { k : self.function(v) for k,v in data.items() }
# --------------------------------------
class LoadLinesFromInstruction(EvaluationInstruction):
    def __init__(self, source_getter):
        self.source_getter = source_getter
    def execute(self, ctx):
        source = self.source_getter.get(ctx)
        for line in self._extract_lines(source, ctx):
            ctx.source.add(line)
    def _extract_lines(self, source, ctx):
        stream = self._open_stream(source, ctx)
        for line in stream:
            sline = line.strip()
            if sline != '':
                yield sline
        stream.close()
    def _open_stream(self, source, ctx):
        try:
            return open(source, 'r')
        except IOError as e:
            raise TesFileError(str(e))
# --------------------------------------
class LoadDatamapInstruction(LoadLinesFromInstruction):
    def execute(self, ctx):
        source = self.source_getter.get(ctx)
        curr_key = None
        for line in self._extract_lines(source, ctx):
            mapping = line.split(':')
            if len(mapping) > 1:
                curr_key = mapping[0].strip()
                ctx.source.add(curr_key, mapping[1].strip())
            else:
                ctx.source.append(curr_key, line.strip())
# --------------------------------------
class ScriptCallInstruction(EvaluationInstruction):
    def __init__(self, caller, parameters):
        self.caller = caller
        self.parameters = parameters
    def execute(self, ctx):
        pvalues = [p.get(ctx) for p in self.parameters]
        ctx.set_params(pvalues)
        ctx.set_result(self.caller.call(ctx))
        ctx.pop_params()
# --------------------------------------
class AssignmentInstruction(EvaluationInstruction):
    def __init__(self, setter, vgetter):
        self.setter = setter
        self.vgetter = vgetter

    def execute(self, ctx):
        value = self.vgetter.get(ctx)
        self.setter.set(value, ctx)
# --------------------------------------
class DataEnsureInstruction(EvaluationInstruction):
    def __init__(self, lgetter, rgetter, bfun):
        self.lgetter = lgetter
        self.rgetter = rgetter
        self.bfun = bfun
    def execute(self, ctx):
        lvalue = self.lgetter.get(ctx)
        rvalue = self.rgetter.get(ctx)
        if not self.bfun(lvalue, rvalue):
            raise TesEnsureError('Unprecized Asked Ensurement Failure')
# --------------------------------------
class SaveContextInstruction(EvaluationInstruction):
    def execute(self, ctx):
        import dill as pickle
        serialization_stream = open(self._export_filename(), 'wb')
        pickle.dump(ctx._comp_ctx, serialization_stream)
        serialization_stream.close()
    def _export_filename(self):
        return '_tescontext_t.{pid}.dat'.format(pid=os.getpid())
# --------------------------------------
class LoadContextInstruction(EvaluationInstruction):
    def __init__(self, source_getter):
        self.source_getter = source_getter
    def execute(self, ctx):
        loaded_ctx = self._load(self.source_getter.get(ctx))
        ctx.update_context(loaded_ctx)
    def _load(self, filename):
        import dill as pickle
        serialization_stream = open(filename, 'rb')
        imported = pickle.load(serialization_stream)
        serialization_stream.close()
        return imported
# --------------------------------------
class ConditionalInstruction(EvaluationInstruction):
    def __init__(self, condition, content):
        self.condition = condition
        self.content = content
    def execute(self, ctx):
        if self.condition.get(ctx):
            self.content.execute(ctx)
# --------------------------------------
class MakeCompareGraphInstruction(EvaluationInstruction):
    def __init__(self, series, filters):
        self.series = series
        self.filters = filters
    def execute(self, ctx):
        valuations = [ s.get(ctx) for s in self.series ]
        graph = Teg.CompareGraph(valuations, self.filters)
        ctx.set_result(graph)
# --------------------------------------
class MakeHistogramInstruction(EvaluationInstruction):
    def __init__(self, series, filters):
        self.series = series
        self.filters = filters
    def execute(self, ctx):
        valuations = [ s.get(ctx) for s in self.series ]
        graph = Teg.HistogramGraph(valuations, self.filters)
        ctx.set_result(graph)
# ======================================
# Tools Structures
# --------------------------------------
class Tool(ToolEvaluationSingleObject):

    def __init__(self, ident, pcount):
        super().__init__(ident, pcount)
        self.executable = None
        self.format = None

        self.evaluations = dict()

        # Pending subparts
        self.requirements = dict()
        self.options = dict()
        self.results = dict()
        self.targets = dict()

    def set_executable(self, value):
        if self.executable is not None:
            raise AttributeError('%s Tool executable already defined: %s' % (self.ident, self.executable))
        self.executable = value

    def set_format(self, value):
        if self.format is not None:
            raise AttributeError('%s Tool format already defined: %s' % (self.ident, self.format))
        self.format = value

    def add_evaluation(self, e, dry=False):
        if dry:
            if e.ident not in self.evaluations:
                raise AttributeError('%s Evaluation does not exist in Tool %s' % (e.ident, self.ident))
        else:
            self.evaluations[e.ident] = e
            e.set_parent(self)

    def add_requirement(self, r, dry=False):
        if dry:
            if r.ident not in self.requirements:
                raise AttributeError('%s Requirement does not exist in Tool %s' % (r.ident, self.ident))
        else:
            self.requirements[r.ident] = r

    def add_option(self, o):
        self.options[o.ident] = o

    def add_result(self, r):
        self.results[r.ident] = r

    def add_data(self, d):
        data_type = type(d).__name__
        if type(d) == type(None):
            pass # This is a non-data part
        elif type(d) == Requirement:
            self.add_requirement(d)
        elif type(d) == Option:
            self.add_option(d)
        elif type(d) == Result:
            self.add_result(d)
        elif type(d) == Evaluation:
            self.add_evaluation(d)
        else:
            raise AttributeError('%s Data cannot be added to Tool type' % data_type)

    def can_be_called(self):
        return '' in self.evaluations

    def get_parameters_range(self):
        return (1 + self.evaluations[''].pcount,
                1 + self.evaluations[''].pcount + len(self.options) + 1)

    def get(self, i):
        if i in self.evaluations:
            return self.evaluations[i]
        if i in self.requirements:
            return self.requirements[i]
        if i in self.options:
            return self.options[i]
        if i in self.results:
            return self.results[i]
        raise AttributeError('No block named %s in Tool %s' % (i, self.ident))

    def call(self, ctx):
        return self.evaluations[''].call(ctx)
# --------------------------------------
class ToolEvaluationResultSet:
    class SerieBrowser:
        def __init__(self, source_table, result_ref):
            self._stable = source_table
            self._res_rf = result_ref

        def __getitem__(self, key):
            return self._stable[key][self._res_rf] if self._res_rf in self._stable[key] else None

        def __setitem__(self, key, value):
            raise TesIllegalModificationError('Serie Browser')

        def __delitem__(self, key):
            raise TesIllegalModificationError('Serie Browser')

        def __iter__(self):
            return self._stable.__iter__()

        def __len__(self):
            return len(self._stable)

    def __init__(self):
        self._results = {}

    def __iter__(self):
        return self._results.__iter__()

    def __getitem__(self, key):
        return self._results[key]

    def __len__(self):
        return len(self._results)

    def add_result(self, ident, value):
        self._results[ident] = value

    def get(self, result):
        return self.SerieBrowser(self, result)
# --------------------------------------
class Evaluation(ToolEvaluationSingleObject):

    def __init__(self, ident, pcount):
        super().__init__(ident, pcount)
        self.additional_options = []
        self._parent = None

    def set_parent(self, p):
        self._parent = p

    def add_additional_option(self, o):
        self.additional_options.append(o)

    def can_be_called(self):
        return True

    def get_parameters_range(self):
        option_c = len(self.options) if self._parent is None else len(self._parent.options)
        return (1 + self.pcount,
                1 + self.pcount + option_c + 1)

    def call(self, ctx):
        param_pset = ctx.params[0]
        param_conf = ctx.params[1:1 + self.pcount]
        param_opts = ctx.params[1 + self.pcount:]
        return self._evaluate(param_pset, param_conf, param_opts, ctx)

    def _evaluate(self, problem_set, configuration, options, ctx):
        results = ToolEvaluationResultSet()
        for example, result in self._execute(problem_set, configuration, options, ctx):
            results.add_result(example, result)
        return results

    def _execute(self, problem_set, configuration, options, ctx):
        for example in problem_set:
            command = self._build_command(example, configuration, options, ctx)
            command_log = self._execute_command(command)
            command_result = self._recover_results(command_log, ctx)
            yield example, command_result

    def _execute_command(self, command):
        proc = Popen(command, stdout=PIPE, stderr=STDOUT)
        cout, cerr = proc.communicate()
        if proc.returncode != 0:
            WarningMessage('Command {c} issued non 0 rv'.format(c=' '.join(command)))
        return cout.decode(sys.stdout.encoding)
    
    def _recover_results(self, command_log, ctx):
        data = dict()
        ctx.set_source(command_log)
        for result_name, result in self._parent.results.items():
            data[result_name] = result.call(ctx)
        ctx.pop_source()
        return data

    def _build_command(self, example, configuration, options, ctx):
        command_string = self._parent.format
        command_string = self._bsu_local_parameters(command_string,
                                                    [self.ident] + [str(p) for p in ctx.params])
        add_opts = []
        for option in options:
            command_string = option.update_command_string(command_string, example, add_opts, ctx)
        for requirement_name, requirement in self._parent.requirements.items():
            requirement.check(example, ctx)
            command_string = command_string.replace('s{rn}'.format(rn=requirement_name), str(ctx.result))
        add_opts.extend(self.additional_options)
        command_string = command_string.replace('$+', ' '.join(add_opts))
        command_string = command_string.replace('$1', example)
        command_string = command_string.replace('$0', self._parent.executable)
        return [cp for cp in command_string.split(' ') if cp != '']

    def _bsu_local_parameters(self, command_string, params):
        for i in range(len(params)):
            command_string = command_string.replace('$&%i' % i, params[i])
        return command_string
# --------------------------------------
class Requirement(ToolEvaluationSingleObject):

    def __init__(self, ident, pcount):
        super().__init__(ident, pcount)
        self.insts = []
        self.generator = None

    def add_step(self, s):
        self.insts.append(s)

    def set_generator(self, generator):
        self.generator = generator

    def check(self, example, ctx):
        try:
            self._check(example, ctx)
        except TesEnsureError:
            self._generate_and_check(example, ctx)

    def _check(self, example, ctx):
        ctx.set_source(example)
        ctx.clear_result()
        for step in self.insts:
            step.execute(ctx)
        ctx.pop_source()

    def _generate_and_check(self, example, ctx):
        if self.generator:
            self.generator.generate(example, ctx)
            return self._is_verified(example, ctx)
        return False
# --------------------------------------
# --------------------------------------
class RequirementGenerator:
    def __init__(self, generator, parameter):
        self.generator = generator
        self.parameter = parameter

    def generate(self, problem):
        raise NotImplementedError(self)
# --------------------------------------
class Option(ToolEvaluationSingleObject):

    class _OptionInstance:
        def __init__(self, option, params):
            self.option = option
            self.params = params

        def update_command_string(self, command_string, example, add_opts, ctx):
            if self.option.new_format is not None:
                params = [command_string] + self.params
                command_string = self.option.new_format
            else:
                params = self.params
            add_opts.extend(self.option.cli_additions)

            for i in range(len(params)):
                # TODO: Not Safe, Update later
                if isinstance(params[i], ToolEvaluationResultSet):
                    params[i] = ToolEvaluationResultSet[example]
                command_string = command_string.replace('$&%i' % i, str(params[i]))
                for _ in range(len(add_opts)):
                    add_opts[_] = add_opts[_].replace('$&%i' % i, str(params[i]))
            return command_string

    def __init__(self, ident, pcount):
        super().__init__(ident, pcount)

        self.new_format = None
        self.cli_additions = []

    def change_format(self, f):
        self.new_format = f
    def add_cli_option(self, o):
        self.cli_additions.append(o)

    def can_be_called(self):
        return True

    def get_parameters_range(self):
        return self.pcount, self.pcount

    def call(self, ctx):
        return self._OptionInstance(self, ctx.params)
# --------------------------------------
class Result(ToolEvaluationSingleObject):

    def __init__(self, ident, pcount):
        super().__init__(ident, pcount)
        self.steps = []

    def add_step(self, s):
        self.steps.append(s)

    def call(self, ctx):
        ctx.clear_result()
        try:
            for step in self.steps:
                step.execute(ctx)
                if ctx.result is None:
                    # In this case, one execution step failed
                    break
            return ctx.result
        except TesInstructionError as e:
            WarningMessage(str(e))
            return None
# --------------------------------------
class Datamap(ToolEvaluationSingleObject):

    def __init__(self, ident, pcount):
        super().__init__(ident, pcount)
        self.load_steps = []
        self.dmap = dict()

    def __iter__(self):
        return self.dmap.__iter__()

    def __getitem__(self, k):
        return self.dmap[k]

    def __len__(self):
        return len(self.dmap)

    def items(self):
        return self.dmap.items()

    def add_step(self, s):
        self.load_steps.append(s)

    def can_be_called(self):
        return len(self.load_steps) > 0

    def get_parameters_range(self):
        return self.pcount, self.pcount

    def call(self, ctx):
        ctx.set_source(self)
        ctx.clear_result()
        try:
            for step in self.load_steps:
                step.execute(ctx)
            self.dmap = ctx.result
        except TesInstructionError as e:
            WarningMessage(str(e))
        ctx.pop_source()

    def add(self, key, val):
        self.dmap[key] = [val]

    def append(self, key, val):
        if key not in self.dmap:
            self.dmap[key] = []
        self.dmap[key].append(val)
# ======================================
# Script Structures
# --------------------------------------
class Script(ToolEvaluationObject):

    def __init__(self, ident, pcount):
        super().__init__(ident, pcount)
        self.parts = []
        self.current_part = None

    def new_part(self, part_id):
        if self.current_part is not None:
            self.parts.append(self.current_part)
        self.current_part = ScriptPart(part_id, self.pcount)

    def add_step(self, s):
        self.current_part.add_instruction(s)

    def prepare(self):
        if self.current_part is not None:
            self.parts.append(self.current_part)
        self.current_part = None

    def execute(self, ctx):
        ctx.set_source(self)
        for part in self.parts:
            part.execute(ctx)
        ctx.pop_source()
# --------------------------------------
class ScriptPart(ToolEvaluationObject):

    def __init__(self, ident, pcount):
        super().__init__(ident, pcount)
        self.instructions = []

    def add_instruction(self, i):
        self.instructions.append(i)

    def execute(self, ctx):
        errors = []
        for instruction in self.instructions:
            try:
                instruction.execute(ctx)
            except TesExecutionError as e:
                sys.stderr.write(str(e))
                errors.append(e)
        if errors:
            raise errors[0]
# --------------------------------------
# ======================================
# Filtering Structures
# --------------------------------------
class Filter(ToolEvaluationSingleObject):

    def __init__(self, ident, pcount, positive=True):
        super().__init__(ident, pcount)
        self.positive = positive
        self.constraints = []

    def add_constraint(self, c):
        self.constraints.append(c)

    def can_be_called(self):
        return True

    def get_parameters_range(self):
        return self.pcount, self.pcount
# --------------------------------------
class Constraint:

    def __init__(self, value_getter):
        self.value_getter = value_getter
# ======================================
# Hangers
# --------------------------------------
class ToolEvaluationHangerType:
    def prepare(self):
        pass
# --------------------------------------
class EvaluationResultHanger(ToolEvaluationHangerType):
    pass
# --------------------------------------
class GraphHanger(ToolEvaluationHangerType):
    _static_subparts = [
        'Title',
        'Xlabel', 'Ylabel'
    ]
    def has(self, n):
        return n in self._static_subparts
# ======================================
# Ensurers functions
# --------------------------------------
class EnsurerComparatorWrapper:

    def __init__(self, source):
        self.source = source

    def __eq__(self, o):
        return self._content_equals_(o) if isinstance(o, EnsurerComparatorWrapper) else False

    def __neq__(self, o):
        return not self.__eq__(o)

    def __getitem__(self, k):
        return self.source[k]

    def __len__(self):
        return self.source.__len__()

    def _content_equals_(self, o):
        status = True
        if len(self) != len(o):
            WarningMessage('Incomparable sizes {s} and {o}'.format(s=len(self), o=len(o)))
            status = False
        for key in self.source:
            svalue = self.source[key]
            okey = o.find_key(key)
            if okey is None:
                WarningMessage('Lone key {k}'.format(k=key))
                status = False
            ovalue = o[okey]
            if svalue != ovalue:
                WarningMessage('On keys {s}, {o} : values differ'.format(s=key, o=okey))
                WarningMessage('Left  value : {s}'.format(s=pformat(svalue)))
                WarningMessage('Right value : {o}'.format(o=pformat(ovalue)))
                status = False
        return status

    def find_key(self, k):
        raise TesImplementationError('Key finder not implemented: {s}'.format(s=self))
# --------------------------------------
class TERSSerieBrowserComparator(EnsurerComparatorWrapper):
    pass
# --------------------------------------
class DatamapComparator(EnsurerComparatorWrapper):

    def find_key(self, k):
        if k in self.source.dmap:
            return k
        for k2 in self.source.dmap:
            if k.endswith(k2) or k2.endswith(k):
                return k2
        return None
# --------------------------------------
def EqualityEnsurer(lvalue, rvalue):
    if isinstance(lvalue, ToolEvaluationResultSet.SerieBrowser):
        lvalue = TERSSerieBrowserComparator(lvalue)
    elif isinstance(lvalue, Datamap):
        lvalue = DatamapComparator(lvalue)
    if isinstance(rvalue, ToolEvaluationResultSet.SerieBrowser):
        rvalue = TERSSerieBrowserComparator(rvalue)
    elif isinstance(rvalue, Datamap):
        rvalue = DatamapComparator(rvalue)
    return lvalue == rvalue
# ======================================
