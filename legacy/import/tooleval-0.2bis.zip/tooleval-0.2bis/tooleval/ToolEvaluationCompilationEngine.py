# --------------------------------------
from antlr4 import FileStream, CommonTokenStream
from antlr4.error.ErrorListener import ErrorListener
from .ToolEvaluationScriptLexer  import ToolEvaluationScriptLexer
from .ToolEvaluationScriptParser import ToolEvaluationScriptParser
from .ToolEvaluationErrors import TesSyntaxError
from .ToolEvaluationLogger import SymbolLocation
from .ToolEvaluationAST import ASTContextSymbol, ASTContext, ASTVisitor
from .ToolEvaluationInterpreter import ToolEvaluationInterpreter
from .ToolEvaluationExporter import ToolEvaluationExporter
from .ASTBuilder import ASTBuilder
from .ASTVisitors import ScriptBuilderVisitor
# --------------------------------------
class CompilationAntlrErrorListener(ErrorListener):

    def __init__(self, source):
        super().__init__()
        self.source = source

    def extractLine(self, cstream, line):
        return cstream.strdata.split('\n')[line]

    def syntaxError(self, recognizer, offendingSymbol, line, column, msg, e):
        line_t = self.extractLine(offendingSymbol.getInputStream(), line - 1)
        size = len(offendingSymbol.text)
        raise TesSyntaxError(msg, SymbolLocation(line_t, self.source, line, column, size))
# --------------------------------------
class FileRequirementsVisitor(ASTVisitor):

    def buildScript(self, node, ctx):
        proot = ctx[ASTContextSymbol('<root>')] if '<root>' in ctx else None
        ctx[ASTContextSymbol('<root>')] = node
        for decl in node.declarations:
            self.build(decl, ctx)
        ctx[ASTContextSymbol('<root>')] = proot

    def buildTopLevelRequirement(self, node, ctx):
        ctx.push_file_requirement(node.location.rsrce)
        requirements = node.get_files()
        ctx.check_requirements_cycle(requirements)
        dumc = CompilationEngine([ r[0] for r in requirements ])
        dumc._build_ast()
        self.build(dumc.ast, ctx)
        ctx[ASTContextSymbol('<root>')].absorb([dumc.ast])
        ctx[ASTContextSymbol('<root>')].declarations.remove(node)
        ctx.pop_file_requirement()
# ======================================
class CompilationEngine:
    def __init__(self, script_files):
        self.script_files = script_files
        self.ast = None
        self.ctx = ASTContext()

    def parse(self):
        self._parse()

    def interpret(self, args):
        self._build_ast()
        self._build_context()
        self._execute(args)

    def compile(self, output_file):
        self._build_ast()
        self._build_context()
        self._export(output_file)

    def _build_parsers(self):
        parsers = []
        for script in self.script_files:
            input  = FileStream(script)
            lexer  = ToolEvaluationScriptLexer(input)
            tokens = CommonTokenStream(lexer)
            parser = ToolEvaluationScriptParser(tokens)
            parser._listeners = [ CompilationAntlrErrorListener(script) ]
            parsers.append(parser)
        return parsers

    def _parse(self):
        parsers = self._build_parsers()
        for parser in parsers:
            parser.script()

    def _build_ast(self):
        builder = ASTBuilder()
        asts = [ builder.visit(parser.script()) for parser in self._build_parsers() ]
        asts[0].absorb(asts[1:])
        self.ast = asts[0]

    def _build_context(self):
        visitors = (FileRequirementsVisitor(), ScriptBuilderVisitor())
        for v in visitors:
            v.build(self.ast, self.ctx)
        self.ctx.prepare()

    def _execute(self, args):
        interpreter = ToolEvaluationInterpreter(self.ctx)
        interpreter.execute(args.script, args.args)

    def _export(self, out):
        exporter = ToolEvaluationExporter(self.ctx)
        exporter.export(out)
# --------------------------------------
