# ======================================
import sys
import numpy as np
# --------------------------------------
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
# ======================================
from .ToolEvaluationErrors import TesImplementationError
# ======================================
# Graphs
# ======================================
class MPLGraph:

    def __init__(self, valuations, filters):
        self.valuations = valuations
        self.filters = filters

        self.figure, self.ax = plt.subplots()

        self._title = None
        self._xlabel = None
        self._ylabel = None

    def set(self, target, value):
        attribute = '_{an}'.format(an=target.lower())
        if hasattr(self, attribute):
            setattr(self, attribute, value)
        else:
            self.local_set(target, value)

    def local_set(self, target, value):
        raise TesImplementationError('<Internal> Graph Setter for %s not implemented' % target)

    def export_file(self, filename):
        if filename is not None:
            self.figure.savefig(filename)
        else:
            self.figure.show()
# --------------------------------------
class CompareGraph(MPLGraph):

    def __init__(self, valuations, filters):
        super().__init__(valuations, filters)

    #TODO : Actually create the graph
# --------------------------------------
class HistogramGraph(MPLGraph):

    def __init__(self, valuations, filters):
        super().__init__(valuations, filters)

    #TODO : Actually create the graph
# ======================================
