# ======================================
import sys
from datetime import datetime
from enum import Enum
from colorama import Style, Fore, Back
# ======================================
# Logging Utilities
# --------------------------------------
class LoggerLevel(Enum):

    GOD_LEVEL    = 0
    FATAL_LEVEL  = 1
    ERROR_LEVEL  = 2
    WARN_LEVEL   = 3
    UNEXP_LEVEL  = 4
    NOTIF_LEVEL  = 5
    INFO_LEVEL   = 6
    STATUS_LEVEL = 7
    TRACE_LEVEL  = 8
    DEBUG_LEVEL  = 9

    def __lt__(self, other):
        return self.value < other.value
    def __le__(self, other):
        return self.value <= other.value
    def __gt__(self, other):
        return self.value > other.value
    def __ge__(self, other):
        return self.value >= other.value
# --------------------------------------
class Logger:

    def __init__(self, level=LoggerLevel.STATUS_LEVEL, wtime=True):
        self.level = level
        self.wtime = wtime


    def _log(self, msg, level):
        if level <= self.level:
            starget = sys.stdout if level > LoggerLevel.WARN_LEVEL else sys.stderr
            print(msg, file=starget)


    def _build_message(self, pre_msg, pre_mod, msg, msg_mod):
        message = []
        if self.wtime:
            message.append(Style.DIM + Fore.MAGENTA)
            message.append('[{time}]'.format(time=datetime.now().replace(microsecond=0)))
            message.append(Style.RESET_ALL)

        message.append(pre_mod)
        message.append(pre_msg)
        message.append(Style.RESET_ALL)

        message.append(msg_mod)
        message.append(msg)
        message.append(Style.RESET_ALL)

        return ''.join(message)

    def result(self, msg, value):
        owt = self.wtime
        self.wtime = False
        printable = self._build_message('[RESULT] ', Style.BRIGHT + Fore.GREEN,
                                        msg, Style.DIM)
        self.wtime = owt
        printable = self._build_message('{p} : '.format(p=printable), '', str(value), Style.BRIGHT)
        self._log(printable, LoggerLevel.GOD_LEVEL)

    def fatal(self, msg):
        printable = self._build_message('[FATAL] ', Style.BRIGHT + Back.RED,
                                        msg, Style.BRIGHT + Fore.RED)
        self._log(printable, LoggerLevel.FATAL_LEVEL)

    def error(self, msg):
        printable = self._build_message('[ERROR] ', Style.BRIGHT + Fore.RED,
                                        msg, Fore.RED)
        self._log(printable, LoggerLevel.ERROR_LEVEL)

    def warn(self, msg):
        printable = self._build_message('[WARN] ', Style.BRIGHT + Fore.YELLOW,
                                        msg, Fore.YELLOW)
        self._log(printable, LoggerLevel.WARN_LEVEL)

    def unexp(self, msg):
        printable = self._build_message('[WARN] ', Fore.YELLOW,
                                        msg, Style.DIM + Fore.YELLOW)
        self._log(printable, LoggerLevel.UNEXP_LEVEL)

    def notif(self, msg):
        printable = self._build_message(' -- ', Style.BRIGHT + Fore.BLUE,
                                        msg, Fore.CYAN)
        self._log(printable, LoggerLevel.NOTIF_LEVEL)

    def info(self, msg):
        printable = self._build_message(' -- ', Style.BRIGHT + Fore.BLUE,
                                        msg, '')
        self._log(printable, LoggerLevel.INFO_LEVEL)

    def status(self, msg):
        printable = self._build_message(' -- ', Fore.BLUE, msg, Style.DIM)
        self._log(printable, LoggerLevel.STATUS_LEVEL)

    def trace(self, msg):
        printable = self._build_message('[TRACE] ', '', msg, Style.DIM)
        self._log(printable, LoggerLevel.TRACE_LEVEL)

    def debug(self, msg):
        printable = self._build_message('[DEBUG] ', Style.DIM, msg, Style.DIM)
        self._log(printable, LoggerLevel.DEBUG_LEVEL)
# ======================================
# ======================================
# File location log
# --------------------------------------
class SymbolLocation:
    def __init__(self, rline, rsrce, rlloc, rcloc, rsize):
        self.rline = rline
        self.rsrce = rsrce
        self.rlloc = rlloc
        self.rcloc = rcloc
        self.rsize = rsize
DummySymbolLocation = SymbolLocation('', '<internal>', 0, 0, 0)
# --------------------------------------
class PrintableMessage:
    def __init__(self, mtype, mcolor, msg):
        self.mtype = mtype
        self.mcolor = mcolor
        self.msg = msg.strip()
    def __str__(self):
        return '%s%s%s : %s%s%s\n' % (Style.BRIGHT + self.mcolor, self.mtype, Style.RESET_ALL,
                                    self.mcolor, self.msg, Style.RESET_ALL)
# --------------------------------------
class PrintableLocatedMessage:
    def __init__(self, mtype, mcolor, m_precolor, msg, astsymb):
        self.mtype = mtype
        self.mcolor = mcolor
        self.m_precolor = m_precolor
        self.msg = msg
        self.rline = astsymb.rline
        self.rsrce = astsymb.rsrce
        self.rlloc = astsymb.rlloc
        self.rcloc = astsymb.rcloc
        self.rsize = astsymb.rsize
    def __str__(self):
        pre_offense  = self.rline[:self.rcloc]
        offender     = self.rline[self.rcloc:self.rcloc + self.rsize]
        post_offense = self.rline[self.rcloc + self.rsize:]
        pre_msg = ('%s:' % self.rsrce + Style.BRIGHT +
                   '@%s:%s : ' % (self.rlloc, self.rcloc) +
                   self.mcolor + self.mtype + ':' + Style.RESET_ALL)
        loc_msg = (self.m_precolor + pre_offense +
                   Style.BRIGHT + self.mcolor + offender +
                   Style.RESET_ALL + Style.DIM + post_offense)
        tgt_msg = (' ' * self.rcloc + Style.BRIGHT + self.mcolor + '^' +
                   Style.NORMAL + '-' * max(self.rsize - 1, 0) + Style.RESET_ALL)
        msg_msg = (' ' * (self.rcloc + 1) + self.mcolor + self.msg + Style.RESET_ALL)
        return '%s\n\n%s\n%s\n%s\n' % (pre_msg, loc_msg, tgt_msg, msg_msg)
# --------------------------------------
def LocatedWarningMessage(msg, loc):
    sys.stderr.write('%s\n' % str(PrintableLocatedMessage('Warning', Fore.YELLOW, Fore.BLUE, msg, loc)))
# --------------------------------------
def WarningMessage(msg):
    sys.stderr.write('%s\n' % str(PrintableMessage('Warning', Fore.YELLOW, msg)).strip())
# --------------------------------------
