# ======================================
from .ToolEvaluation import EvaluationContext
# ======================================
# Interpreter
# --------------------------------------
class ToolEvaluationInterpreter:

    def __init__(self, ctx):
        self.ctx = ctx

    def execute(self, script, args):
        scripts = { s.ident : s for s in self.ctx.contextGet('<scripts>', None) }
        scripts[script].execute(EvaluationContext(args, self.ctx))
# ======================================
