# ======================================
import os, stat
import codecs
import dill as pickle
# ======================================
# Exporter
# --------------------------------------
# TODO: Serialize Local Modules Too
class ToolEvaluationExporter:

    def __init__(self, ctx):
        self.ctx = ctx

    def encode_ctx_data(self):
        return codecs.encode(pickle.dumps(self.ctx), 'base64').decode()

    def export(self, outfile):
        stream = open(outfile, 'w')
        self._write(stream)
        stream.close()
        os.chmod(outfile,
                 stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR |
                 stat.S_IRGRP | stat.S_IXGRP |
                 stat.S_IROTH | stat.S_IXOTH)

    def _write(self, stream):
        stream.write('''#!/usr/bin/env python3
# --------------------------------------
# TES Compiled Script
# --------------------------------------
import sys
import codecs
import dill as pickle
# --------------------------------------
from argparse import ArgumentParser
# --------------------------------------
from tooleval import EvaluationContext
from tooleval.ToolEvaluationErrors import TesExecutionError
# --------------------------------------
_SCRIPT_CONTEXT_DATA = """{context}"""
'''.format(context=self.encode_ctx_data()) +
'''# --------------------------------------
def _load_context_data():
    global _SCRIPT_CONTEXT_DATA
    data = pickle.loads(codecs.decode(_SCRIPT_CONTEXT_DATA.encode(), "base64"))
    return data
# --------------------------------------
def main(args, context, scripts):
    try:
        scripts[args.script].execute(EvaluationContext(args.args, context))
    except TesExecutionError as e:
        sys.stderr.write(str(e))
        sys.exit(1)
# --------------------------------------
if __name__ == '__main__':
    ap = ArgumentParser(description='Compiled Tool Evaluation Script')
    try:
        context = _load_context_data()
    except Exception as e:
        raise ImportError('Compiled content is corrupted') from e
    scripts = { s.ident : s for s in context.contextGet('<scripts>', None) }
    ap.add_argument('-s', '--script', required=True,
                    choices=list(scripts),
                    help='script to interprete')
    ap.add_argument('-a', '--args', nargs='+',
                    help='define script arguments for interpretation')
    main(ap.parse_args(), context, scripts)
# --------------------------------------
''')
# ======================================
