# --------------------------------------
from antlr4 import ParseTreeVisitor
from .ToolEvaluationLogger import SymbolLocation
from .ToolEvaluationAST import *
# --------------------------------------
if __name__ is not None and "." in __name__:
    from .ToolEvaluationScriptParser import ToolEvaluationScriptParser
else:
    from ToolEvaluationScriptParser import ToolEvaluationScriptParser
# --------------------------------------
def generateSymbolLocation(ctx):
    token  = ctx.start
    source = token.getTokenSource().inputStream.fileName
    line   = token.line
    col    = token.column
    line_text = token.getInputStream().strdata.split('\n')[line-1]
    size   = len(token.text)
    return SymbolLocation(line_text, source, line, col, size)
# --------------------------------------
class ASTBuilder(ParseTreeVisitor):

    def visitScript(self, ctx:ToolEvaluationScriptParser.ScriptContext):
        loc = generateSymbolLocation(ctx)
        script = ScriptNode(loc)
        for block in ctx.block_declaration():
            script.add_block(self.visit(block))
        for tldecl in ctx.top_level_declaration():
            script.add_declaration(self.visit(tldecl))
        return script

    def visitTop_level_declaration(self, ctx:ToolEvaluationScriptParser.Top_level_declarationContext):
        return self.visitChildren(ctx)

    def visitTop_level_requirement(self, ctx:ToolEvaluationScriptParser.Top_level_requirementContext):
        loc = generateSymbolLocation(ctx)
        return TopLevelRequirementNode(loc, self.visit(ctx.identifier_list()))

    def visitBlock_declaration(self, ctx:ToolEvaluationScriptParser.Block_declarationContext):
        loc = generateSymbolLocation(ctx.block_name)
        param_count = int(ctx.block_parameters.text) if ctx.block_parameters is not None else 0
        block = BlockNode(loc, self.visit(ctx.block_name), self.visit(ctx.block_type),
                          param_count, self.visit(ctx.block_definition()))
        decorator_list = ctx.decorator_list()
        if decorator_list is not None:
            block.add_decorators(self.visit(decorator_list))
        return block

    def visitBlock_definition(self, ctx:ToolEvaluationScriptParser.Block_definitionContext):
        return [ self.visit(content) for content in ctx.block_content() ]

    def visitBlock_content(self, ctx:ToolEvaluationScriptParser.Block_contentContext):
        return [ self.visit(part) for part in ctx.block_part() ]

    def visitBlock_part(self, ctx:ToolEvaluationScriptParser.Block_partContext):
        return self.visitChildren(ctx)

    def visitExecutable_definition(self, ctx:ToolEvaluationScriptParser.Executable_definitionContext):
        loc = generateSymbolLocation(ctx)
        return ExecutableDefNode(loc, self.visit(ctx.non_parametrized_string_literal()))

    def visitFormat_definition(self, ctx:ToolEvaluationScriptParser.Format_definitionContext):
        loc = generateSymbolLocation(ctx)
        return FormatDefNode(loc, self.visit(ctx.parametrized_string_literal()))

    def visitReference_evaluation(self, ctx:ToolEvaluationScriptParser.Reference_evaluationContext):
        loc = generateSymbolLocation(ctx)
        return EvaluationRequestNode(loc, self.visit(ctx.reference()))

    def visitReference_requirement(self, ctx:ToolEvaluationScriptParser.Reference_requirementContext):
        loc = generateSymbolLocation(ctx)
        return RequirementRequestNode(loc, self.visit(ctx.reference()))

    def visitConditional_block_part(self, ctx:ToolEvaluationScriptParser.Conditional_block_partContext):
        loc = generateSymbolLocation(ctx)
        return ConditionalBlockNode(loc, self.visit(ctx.value()), self.visit(ctx.block_definition()))

    def visitFunction_call(self, ctx:ToolEvaluationScriptParser.Function_callContext):
        loc = generateSymbolLocation(ctx)
        identifier = ctx.subtarget
        subtarget = self.visit(identifier) if identifier is not None else None
        return FunctionCallNode(loc, self.visit(ctx.function_name), subtarget,
                                self.visit(ctx.parameter_list()))

    def visitAssignment(self, ctx:ToolEvaluationScriptParser.AssignmentContext):
        loc = generateSymbolLocation(ctx)
        identifier = ctx.identifier()
        subtarget = self.visit(identifier) if identifier is not None else None
        return AssignmentNode(loc, self.visit(ctx.identifier_list()), subtarget, self.visit(ctx.value()))

    def visitVariable_export(self, ctx:ToolEvaluationScriptParser.Variable_exportContext):
        loc = generateSymbolLocation(ctx)
        return VariableExportNode(loc, self.visit(ctx.identifier_list()),
                                  self.visit(ctx.non_parametrized_string_literal_list()))

    def visitBoolean_constraint(self, ctx:ToolEvaluationScriptParser.Boolean_constraintContext):
        return self.visitChildren(ctx)

    def visitBoolean_constraint_0(self, ctx:ToolEvaluationScriptParser.Boolean_constraint_0Context):
        return self.visitChildren(ctx)

    def visitBoolean_constraint_1(self, ctx:ToolEvaluationScriptParser.Boolean_constraint_1Context):
        return self.visitChildren(ctx)

    def visitBoolean_unary_constraint(self, ctx:ToolEvaluationScriptParser.Boolean_unary_constraintContext):
        loc = generateSymbolLocation(ctx)
        operator = self.visit(ctx.boolean_unary_operator())
        parameters = [ self.visit(ctx.boolean_constraint_1()) ]
        return BooleanConstraintNode(loc, operator, parameters)

    def visitBoolean_binary_constraint(self, ctx:ToolEvaluationScriptParser.Boolean_binary_constraintContext):
        loc = generateSymbolLocation(ctx)
        operator = self.visit(ctx.boolean_binary_operator())
        parameters = [ self.visit(constraint) for constraint in ctx.boolean_constraint_1() ]
        return BooleanConstraintNode(loc, operator, parameters)

    def visitBoolean_comparison_constraint(self, ctx:ToolEvaluationScriptParser.Boolean_comparison_constraintContext):
        loc = generateSymbolLocation(ctx)
        operator = self.visit(ctx.value_binary_operator())
        parameters = [ self.visit(value) for value in ctx.value() ]
        return BooleanConstraintNode(loc, operator, parameters)

    def visitIdentifier_list(self, ctx:ToolEvaluationScriptParser.Identifier_listContext):
        return [ self.visit(identifier) for identifier in ctx.identifier() ]

    def visitValue_list(self, ctx:ToolEvaluationScriptParser.Value_listContext):
        return [ self.visit(value) for value in ctx.value() ]

    def visitParameter_list(self, ctx:ToolEvaluationScriptParser.Parameter_listContext):
        return self.visitChildren(ctx)

    def visitDecorator_list(self, ctx:ToolEvaluationScriptParser.Decorator_listContext):
        return [ self.visit(decorator) for decorator in ctx.decorator() ]

    def visitNon_parametrized_string_literal_list(self, ctx:ToolEvaluationScriptParser.Non_parametrized_string_literal_listContext):
        return [ self.visit(literal) for literal in ctx.non_parametrized_string_literal() ]

    def visitValue(self, ctx:ToolEvaluationScriptParser.ValueContext):
        return self.visitChildren(ctx)

    def visitIdentifier(self, ctx:ToolEvaluationScriptParser.IdentifierContext):
        loc = generateSymbolLocation(ctx)
        return IdentifierNode(loc, ctx.IDENTIFIER().getText())

    def visitReference(self, ctx:ToolEvaluationScriptParser.ReferenceContext):
        loc = generateSymbolLocation(ctx)
        return ReferenceNode(loc, ctx.REFERENCE().getText()[1:])

    def visitDecorator(self, ctx:ToolEvaluationScriptParser.DecoratorContext):
        loc = generateSymbolLocation(ctx)
        identifier = ctx.identifier()
        value = self.visit(identifier) if identifier is not None else None
        return DecoratorNode(loc, ctx.DECORATOR().getText()[1:], value)

    def visitIdentifier_access(self, ctx:ToolEvaluationScriptParser.Identifier_accessContext):
        loc = generateSymbolLocation(ctx)
        return AccessNode(loc, self.visit(ctx.identifier()), self.visit(ctx.local))

    def visitReference_access(self, ctx:ToolEvaluationScriptParser.Reference_accessContext):
        loc = generateSymbolLocation(ctx)
        return AccessNode(loc, self.visit(ctx.reference()), self.visit(ctx.local))

    def visitInteger_literal(self, ctx:ToolEvaluationScriptParser.Integer_literalContext):
        loc = generateSymbolLocation(ctx)
        return IntegerNode(loc, int(ctx.INT().getText()))

    def visitFloat_literal(self, ctx:ToolEvaluationScriptParser.Float_literalContext):
        loc = generateSymbolLocation(ctx)
        return FloatNode(loc, float(ctx.FLOAT().getText()))

    def visitNon_parametrized_string_literal(self, ctx:ToolEvaluationScriptParser.Non_parametrized_string_literalContext):
        loc = generateSymbolLocation(ctx)
        return NonParametrizedStringNode(loc, ctx.NON_PARAMETRIZED_STRING().getText()[1:-1])

    def visitParametrized_string_literal(self, ctx:ToolEvaluationScriptParser.Parametrized_string_literalContext):
        loc = generateSymbolLocation(ctx)
        return ParametrizedStringNode(loc, ctx.PARAMETRIZED_STRING().getText()[1:-1])

    def visitString_literal(self, ctx:ToolEvaluationScriptParser.String_literalContext):
        return self.visitChildren(ctx)

    def visitBoolean_unary_operator(self, ctx:ToolEvaluationScriptParser.Boolean_unary_operatorContext):
        loc = generateSymbolLocation(ctx)
        return OperatorNode(loc, ctx.getText())

    def visitBoolean_binary_operator(self, ctx:ToolEvaluationScriptParser.Boolean_binary_operatorContext):
        loc = generateSymbolLocation(ctx)
        return OperatorNode(loc, ctx.getText())

    def visitValue_binary_operator(self, ctx:ToolEvaluationScriptParser.Value_binary_operatorContext):
        loc = generateSymbolLocation(ctx)
        return OperatorNode(loc, ctx.getText())
# --------------------------------------
