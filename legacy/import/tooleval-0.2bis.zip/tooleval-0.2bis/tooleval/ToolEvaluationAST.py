# --------------------------------------
import os
# --------------------------------------
from .ToolEvaluationLogger import LocatedWarningMessage, SymbolLocation, DummySymbolLocation
from .ToolEvaluationErrors import TesContextError
# ======================================
class ASTContextSymbol:
    def __init__(self, name, loc=DummySymbolLocation):
        self.name = name
        self.loc = loc
# --------------------------------------
class ASTContext:

    def __init__(self):
        self.fdep_engine = FileDependencyCycleChecker()
        self.pending = set()
        self.hashtable = {}

    def prepare(self):
        for k, v in self.hashtable.items():
            if not k.startswith('<'):
                v[0].prepare()

    def push_file_requirement(self, filedat):
        self.fdep_engine.push(filedat[0])
    def pop_file_requirement(self):
        return self.fdep_engine.pop()
    def check_requirements_cycle(self, flist):
        self.fdep_engine.ensure(flist)

    def __setitem__(self, k, v):
        if k.name.startswith('<'):
            self.hashtable[k.name] = (v, k.loc)
        else:
            self.contextSet(k.name, v, k.loc)
    def __getitem__(self, k):
        if k.name.startswith('<'):
            return self.hashtable[k.name][0]
        return self.contextGet(k.name, k.loc)
    def __contains__(self, k):
        if k.startswith('<'):
            return self.hashtable.__contains__(k)
        return self.contextHas(k)

    def _contextGet(self, name, loc):
        parents = [ p for p in self.hashtable['<root>'][0] ]
        while parents:
            ident = '.'.join(parents + [name])
            if ident in self.hashtable:
                return self.hashtable[ident]
            parents.pop()
        if name in self.hashtable:
            return self.hashtable[name]
        raise TesContextError('Unknown variable: %s' % name, loc)

    def contextGet(self, name, loc):
        return self._contextGet(name, loc)[0]

    def contextLocation(self, name, loc):
        return self._contextGet(name, loc)[1]

    def contextHas(self, name):
        try:
            self.contextGet(name, DummySymbolLocation)
            return True
        except TesContextError:
            return False

    def contextSet(self, name, value, loc):
        parents = [ p for p in self.hashtable['<root>'][0] ]
        ident = '.'.join(parents + [name])
        if ident in self.hashtable:
            LocatedWarningMessage('Duplicate definition here', self.hashtable[ident][1])
            raise TesContextError('Duplicate symbol: %s' % name, loc)
        self.hashtable[ident] = (value, loc)

    def update(self, lctx):
        for k,v in lctx.hashtable.items():
            self.hashtable[k] = v
            # TODO: Finner Context Update
# --------------------------------------
class FileDependencyCycleChecker:
    def __init__(self):
        self.fstack = []
    def push(self, fname):
        self.fstack.append(fname)
    def pop(self):
        return self.fstack.pop()
    def ensure(self, flist):
        for req, loc in flist:
            if req in self.fstack:
                raise TesContextError('Cyclic file requirement', loc)
# ======================================
class ASTVisitor:

    def build(self, root, ctx:ASTContext):
        visitor = 'build%s' % type(root).__name__.replace('Node', '')
        try:
            return getattr(self, visitor)(root, ctx)
        except AttributeError as e:
            LocatedWarningMessage(str(e), root.location)
            typename = type(root).__name__.replace('Node', '')
            raise TesContextError('%s type is not buildable' % typename, root.location)

    def buildGetter(self, root, ctx:ASTContext):
        builder = 'build%sGetter' % type(root).__name__.replace('Node', '')
        try:
            return getattr(self, builder)(root, ctx)
        except AttributeError as e:
            LocatedWarningMessage(str(e), root.location)
            typename = type(root).__name__.replace('Node', '')
            raise TesContextError('%s type is not gettable' % typename, root.location)

    def buildSetter(self, root, ctx:ASTContext):
        builder = 'build%sSetter' % type(root).__name__.replace('Node', '')
        try:
            return getattr(self, builder)(root, ctx)
        except AttributeError as e:
            LocatedWarningMessage(str(e), root.location)
            typename = type(root).__name__.replace('Node', '')
            raise TesContextError('%s type is not settable' % typename, root.location)
# ======================================
# AST
class ASTNode:
    def __init__(self, location:SymbolLocation):
        self.location = location
# --------------------------------------
class ScriptNode(ASTNode):

    def __init__(self, location:SymbolLocation):
        super().__init__(location)
        self.declarations = []
        self.blocks = []

    def absorb(self, scripts):
        for script in scripts:
            self.declarations.extend(script.declarations)
            script.blocks.extend(self.blocks)
            self.blocks = script.blocks

    def add_block(self, block):
        self.blocks.append(block)

    def add_declaration(self, decl):
        self.declarations.append(decl)
# --------------------------------------
class TopLevelRequirementNode(ASTNode):

    def __init__(self, location:SymbolLocation, identifiers):
        super().__init__(location)
        self.identifiers = identifiers

    def get_files(self):
        return [ (ident.to_filename(), ident.location) for ident in self.identifiers ]
# --------------------------------------
class BlockNode(ASTNode):

    def __init__(self, location:SymbolLocation, name, btype, bparams, content):
        super().__init__(location)
        self.name = name
        self.btype = btype
        self.bparams = bparams
        self.content = content
        self.decorators = []

    def add_decorators(self, decorators):
        self.decorators.extend(decorators)
# --------------------------------------
class ExecutableDefNode(ASTNode):

    def __init__(self, location:SymbolLocation, value):
        super().__init__(location)
        self.value = value
# --------------------------------------
class FormatDefNode(ASTNode):

    def __init__(self, location:SymbolLocation, value):
        super().__init__(location)
        self.value = value
# --------------------------------------
class EvaluationRequestNode(ASTNode):

    def __init__(self, location:SymbolLocation, ref):
        super().__init__(location)
        self.ref = ref
# --------------------------------------
class RequirementRequestNode(ASTNode):

    def __init__(self, location:SymbolLocation, ref):
        super().__init__(location)
        self.ref = ref
# --------------------------------------
class ConditionalBlockNode(ASTNode):

    def __init__(self, location:SymbolLocation, test, content):
        super().__init__(location)
        self.test = test
        self.content = content
# --------------------------------------
class FunctionCallNode(ASTNode):

    def __init__(self, location:SymbolLocation, fname, fpart, parameters):
        super().__init__(location)
        self.fname = fname
        self.fpart = fpart
        self.parameters = parameters
# --------------------------------------
class AssignmentNode(ASTNode):

    def __init__(self, location:SymbolLocation, targets, subtarget, value):
        super().__init__(location)
        self.targets = targets
        self.subtarget = subtarget
        self.value = value
# --------------------------------------
class VariableExportNode(ASTNode):

    def __init__(self, location:SymbolLocation, variables, targets):
        super().__init__(location)
        self.variables = variables
        self.targets = targets
# --------------------------------------
class BooleanConstraintNode(ASTNode):

    def __init__(self, location:SymbolLocation, operation, parameters):
        super().__init__(location)
        self.operation = operation
        self.parameters = parameters
# --------------------------------------
class IdentifierNode(ASTNode):

    def __init__(self, location:SymbolLocation, name):
        super().__init__(location)
        self.name = name

    def to_filename(self):
        for pfname in (self.name, '%s.tes' % self.name,
                       os.path.join(os.path.dirname(self.location.rsrce), self.name),
                       os.path.join(os.path.dirname(self.location.rsrce), '%s.tes' % self.name)):
            if os.path.isfile(pfname):
                return pfname
        raise TesContextError('Could not find file: %s' % self.name, self.location)
# --------------------------------------
class ReferenceNode(ASTNode):

    def __init__(self, location:SymbolLocation, name):
        super().__init__(location)
        self.name = name
# --------------------------------------
class DecoratorNode(ASTNode):

    def __init__(self, location:SymbolLocation, name, value):
        super().__init__(location)
        self.name = name
        self.value = value
# --------------------------------------
class AccessNode(ASTNode):

    def __init__(self, location:SymbolLocation, source, name):
        super().__init__(location)
        self.source = source
        self.name = name
# --------------------------------------
class LiteralNode(ASTNode):

    def __init__(self, location:SymbolLocation, value):
        super().__init__(location)
        self.value = value
# --------------------------------------
class IntegerNode(LiteralNode):
    pass
# --------------------------------------
class FloatNode(LiteralNode):
    pass
# --------------------------------------
class NonParametrizedStringNode(LiteralNode):
    pass
# --------------------------------------
class ParametrizedStringNode(LiteralNode):
    pass
# --------------------------------------
class OperatorNode(ASTNode):

    def __init__(self, location:SymbolLocation, operator):
        super().__init__(location)
        self.operator = operator
# ======================================
