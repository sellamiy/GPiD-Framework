# -------------------
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .io import Logger
from .core import UndefinedEvaluationResultException, IllegalReferenceException
# -------------------
def buildJointSeries(pset, references, typeconvs=None, filters=None, associated=False):
    if typeconvs is None:
        typeconvs = dict()
    if filters is None:
        filters = []
    for reference in references:
        if not reference.startswith('&'):
            raise IllegalReferenceException(reference)
    filenames = []
    series    = tuple([] for _ in range(len(references)))
    for pdata in pset:
        try:
            filtering = [ f(pdata) for f in filters ]
            if True in filtering:
                continue
            values = dict()
            for reference in references:
                values[reference] = pdata.get_reference(reference)
            for _ in range(len(references)):
                filenames.append(pdata.problem_file)
                serie_value = values[references[_]]
                if references[_] in typeconvs:
                    serie_value = typeconvs[references[_]](serie_value)
                series[_].append(serie_value)
        except UndefinedEvaluationResultException:
            pass
    if associated:
        return (filenames,) + series
    else:
        return series
# -------------------
def exportFigure(figure, filename):
    if filename is not None:
        figure.savefig(filename)
    else:
        figure.show()

def exportTable(tables, filename):
    cats = tables[0]
    lseries = tables[1]
    stream = open(filename, 'w')
    stream.write('Size&')
    stream.write('&'.join([ '$[{a},{b}[$'.format(a=c[0],b=c[1]) for c in cats ]))
    stream.write('\\\\\\hline\n')
    i = 1
    for s in lseries:
        stream.write('${i}$&'.format(i=i))
        stream.write('&'.join([ '${a}$'.format(a=a) for a in lseries[i-1] ]))
        stream.write('\\\\\\hline\n')
        i+=1
    stream.close()
# -------------------
def exportFile(tdata, filename):
    if filename is not None:
        stream = open(filename, 'w')
        stream.write(tdata)
        stream.close()
    else:
        sys.stdout.write(tdata)
# -------------------
class ProblemFilter:

    def __init__(self, reference, filter_cond):
        self.reference = reference
        self.filter_cond = filter_cond

    def __call__(self, data):
        try:
            value = data.get_reference(self.reference)
            return self.filter_cond(value)
        except UndefinedEvaluationResultException:
            # Filter non computable filter conditions
            return True
# -------------------
class ProblemMultiFilter:

    def __init__(self, references, filter_cond):
        self.references = references
        self.filter_cond = filter_cond

    def __call__(self, data):
        try:
            value = []
            for reference in self.references:
                value.append(data.get_reference(reference))
            return self.filter_cond(value)
        except UndefinedEvaluationResultException:
            # Filter non computable filter conditions
            return True
# -------------------
class AbstractGrapher:

    def __init__(self, references, typeconvs=None, filters=None, requires_filenames=False):
        self.references    = references
        self.typeconvs     = typeconvs
        self.filters       = filters
        self.req_filenames = requires_filenames

    def create_graph(self, pset, filename=None):
        series = buildJointSeries(pset, self.references, self.typeconvs, self.filters, self.req_filenames)
        figure = self.generate_figure(series)
        exportFigure(figure, filename)

    def generate_figure(self, series):
        raise NotImplementedError(self)
# -------------------
class SerieCompareGrapher(AbstractGrapher):

    def __init__(self, r1, r2, t1, t2, title='', xlabel='', ylabel='', logscale=False):
        super().__init__([r1, r2], typeconvs={ r1:t1, r2:t2 })
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.logscale = logscale

    def generate_figure(self, series):
        figure, ax = plt.subplots()
        figure.suptitle(self.title)
        ax.set_xlabel(self.xlabel)
        ax.set_ylabel(self.ylabel)
        if self.logscale:
            ax.set_xscale('log')
            ax.set_yscale('log')
        ax.scatter(series[0], series[1], marker='x')
        self._plot_x___eq___y(ax)
        return figure

    def _plot_x___eq___y(self, ax):
        lims = [
            np.min([ax.get_xlim(), ax.get_ylim()]),
            np.max([ax.get_xlim(), ax.get_ylim()]),
        ]

        ax.plot(lims, lims, 'k-', alpha=0.75, zorder=0)
        # ax.set_aspect('equal')
        ax.set_xlim(lims)
        ax.set_ylim(lims)
# -------------------
class ProblemCatSplitter(AbstractGrapher):

    def __init__(self, categorizer, catnames, title=''):
        super().__init__(None)
        self.categorizer = categorizer
        self.catnames    = catnames
        self.title       = title

    def create_graph(self, pset, filename=None):
        figure = self.generate_figure(pset)
        exportFigure(figure, filename)

    def generate_figure(self, pset):
        catvalues = dict()
        for pbl in pset:
            cat = self.categorizer(pbl)
            if cat not in catvalues:
                catvalues[cat] = 0
            catvalues[cat] += 1

        f_labels = []
        f_sizes  = []
        for cat in catvalues:
            if cat >= 0:
                f_labels.append(self.catnames[cat])
                f_sizes .append(catvalues[cat])

        figure, ax = plt.subplots()
        figure.suptitle(self.title)
        ax.pie(f_sizes, labels=f_labels)
        return figure
# -------------------
class SeriesCatSplitter(AbstractGrapher):

    def __init__(self, references, categorizer, catnames, typeconvs=None, title=''):
        super().__init__(references, typeconvs)
        self.categorizer = categorizer
        self.catnames    = catnames
        self.title       = title

    def generate_figure(self, series):
        catvalues = dict()
        for _ in range(len(series[0])):
            cat = self.categorizer(tuple((s[_] for s in series)))
            if cat not in catvalues:
                catvalues[cat] = 0
            catvalues[cat] += 1

        f_labels = []
        f_sizes  = []
        for cat in catvalues:
            if cat >= 0:
                f_labels.append(self.catnames[cat])
                f_sizes .append(catvalues[cat])

        figure, ax = plt.subplots()
        figure.suptitle(self.title)
        ax.pie(f_sizes, labels=f_labels)
        return figure
# -------------------
class SerieHistogram(AbstractGrapher):

    def __init__(self, sid, sid_mod, filters=None, title='', xlabel='', ylabel=''):
        super().__init__([sid], typeconvs={ sid:sid_mod }, filters=filters)
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel

    def generate_figure(self, series):
        figure, ax = plt.subplots()
        figure.suptitle(self.title)
        ax.set_xlabel(self.xlabel)
        ax.set_ylabel(self.ylabel)
        ax.hist(series[0], 50)
        return figure
# -------------------
class MultiSerieHistogram(AbstractGrapher):

    def __init__(self, sids, sid_mods, sid_size, sid_legends, filters=None, title='', xlabel='', ylabel=''):
        super().__init__(sids, typeconvs=sid_mods, filters=filters)
        self.sid_legends = sid_legends
        self.sid_size = sid_size
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel

    def generate_figure(self, series):
        figure, ax = plt.subplots()
        figure.suptitle(self.title)
        ax.set_xlabel(self.xlabel)
        ax.set_ylabel(self.ylabel)
        # Local HACK
        series = [ [ min(i, 10) for i in s ] for s in series ]
        ax.hist(series, self.sid_size, label=self.sid_legends)
        return figure
# -------------------
class MultiSerieHistogramAsTable(MultiSerieHistogram):
    def __init__(self, sids, sid_mods, sid_size, sid_legends, filters=None, title='', xlabel='', ylabel=''):
        super().__init__(sids, sid_mods, sid_size, sid_legends, filters, title, xlabel, ylabel)
    def generate_figure(self, series):
        # HACK
        cats = [(0, 0.5), (0.5, 1), (1, 1.5), (1.5, 2), (2, 5), (5, 10), (10, 30), (0,0)]
        cseries = [ [ len([i for i in s if i>=c[0] and i<c[1]]) for c in cats ] for s in series]
        for s in cseries:
            s[-1] = self.sid_size - sum(s[:-1])
        return cats, cseries
    def create_graph(self, pset, filename=None):
        series = buildJointSeries(pset, self.references, self.typeconvs, self.filters, self.req_filenames)
        figure = self.generate_figure(series)
        exportTable(figure, filename)
# -------------------
class ValueXtractor:

    def __init__(self, name, problem_value_f, valueL_value_f):
        self.name = name
        self.problem_value_f = problem_value_f
        self.valueL_value_f  = valueL_value_f

    def extract(self, pset):
        value_list = []
        for pdata in pset:
            pval = self.problem_value_f(pdata)
            if pval is not None:
                value_list.append(pval)
        return self.valueL_value_f(value_list)

    def get_name(self):
        return self.name
# -------------------

